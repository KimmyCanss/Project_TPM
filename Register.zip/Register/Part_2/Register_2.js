function selectOption(option) {
  // Your existing code here

  // Update the conditions for 'laki-laki' and 'perempuan'
  if (option === 'laki-laki') {
    // Your logic for 'laki-laki'
  } else if (option === 'perempuan') {
    // Your logic for 'perempuan'
  }
}
